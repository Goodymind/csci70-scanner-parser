#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "scan.h"
#include "dirent.h"
#include "parse.h"

// checks if string has word input in it
// returns index
int find_input(char *str)
{
    char *pos = strstr(str, "input");
    if (pos == NULL)
        return -1;
    return (int)(pos - str);
}

// builds output file name
char *buildoutputfilename(int inputindex, char *filename)
{
    // if it has input in the name, replace with parser_output
    if (inputindex > -1)
    {
        const char *outputstr = "parser_output";
        const size_t in_len = 5; // strlen("input")

        size_t len = strlen(filename) + 1;    // includes '\0'
        size_t outputlen = strlen(outputstr); // NO null terminator

        char *buf = malloc(len - in_len + outputlen);
        if (buf == NULL)
            return NULL;

        memcpy(buf, filename, inputindex);
        memcpy(buf + inputindex, outputstr, outputlen);
        memcpy(buf + inputindex + outputlen,
               filename + inputindex + in_len,
               len - inputindex - in_len);

        return buf; // freed by caller
    }
    // if it does not have input in the name, append _parser_output before .txt
    else
    {

        const char *outputstr = "_parser_output";

        size_t len = strlen(filename) + 1;    // include \0
        size_t outputlen = strlen(outputstr); // do not include \0

        int target = len - 5;
        // ".txt0";

        char *buf = malloc(len + outputlen);

        if (buf == NULL)
            return NULL;

        memcpy(buf, filename, target);
        memcpy(buf + target, outputstr, outputlen);
        memcpy(buf + target + outputlen,
               filename + target, 5);

        return buf;
    }
}

int main(int argc, char **argv)
{

    if (argc != 2)
    {
        fprintf(stderr, "Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    char* filename = argv[1];

    int inputstringindex = find_input(filename);

    char *output = buildoutputfilename(inputstringindex, filename);

    if (output == NULL)
    {
        perror("Failed to create output filename");
    }
    // redirect stdout to output file
    if (freopen(output, "w", stdout) == NULL)
    {
        perror("Failed to redirect stdout");
        free(output);
    }

    parse(filename);

    free(output);
}